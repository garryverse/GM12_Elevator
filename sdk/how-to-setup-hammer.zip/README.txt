==================== GENERAL MAPPING GUIDE: ====================

Prerequisites:
- Must have downloaded and extracted this repo and extract it somewhere easy to locate
- Must have downloaded the server version of gmod 12: https://dl.flatgrass.net/data/gmod12-flatgrass-srcds.7z
- The server download must be located at C:/Program Files (x86)/Steam/steamapps/common/ under the folder name "GarrysMod12Server" (no quotes)

NOTE: This guide assumes you have your files at these specific paths. Adapt this guide to your setup.
Additionally the hammer configuration files are preconfigured to the same paths; modify them only if you have your's setup elsewhere.
C:/Program Files (x86)/Steam/steamapps/common/GarrysMod12Server/
C:/Program Files (x86)/Steam/steamapps/common/GarrysModTwelve/
C:/Program Files (x86)/Steam/steamapps/common/SourceSDK/

Step 1: Go to your Steam library and search for "Source SDK"
Step 2: Install it
Step 3: After its installed, right click it and go to Manage -> Browse local files
Step 4: Inside the Source SDK files, navigate to the "bin" folder
Step 5: Return to the folder for this guide
Step 6: Navigate to the "gamecfgs" folder within
Step 7: Copy the both folders and paste them into the Source SDK folder you navigated to previously
Step 8: Always replace the existing file if asked (Don't worry. this is fine. all it does is add a pre-made gmod 12 hammer config)
Step 9: Navigate to C:/Program Files (x86)/Steam/steamapps/common/GarrysMod12Server/garrysmod/
Step 10: Inside there, replace the gameinfo.txt file with the one from this guide
Step 11: if you have any mountable content (eg. tf2) already in your gmod 12 client folder, copy them to the root of the server folder (The server version doesn't have cstrike bundled by default. you can get it from dl.flatgrass.net)
YOU'RE DONE!

================================================================

NOTE: you need to manually point at individual addon folders.
old 2009/orangebox hammer doesn't have wildcard support for configs.
to point at the addons you want to get mounted by hammer, open up the gameinfo.txt file
and change this line:
Game				|gameinfo_path|addons
to:
Game				|gameinfo_path|addons\name_of_addon
(you can clone this line to add as as many addons as you want)

to make this work, you need to use the server version and point all the content to the server's garrysmod directory.

in simple terms: all assets gets pointed to the garrysmod directory from the server download on flatgrass.net
while the game executable stays as the client version.

this is because the old hammer needed for map making (and other tools) don't support vpks